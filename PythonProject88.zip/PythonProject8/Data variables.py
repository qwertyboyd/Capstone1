firstName = int(input( "Enter you name:"))
lastName = int(input( "Enter your last name:"))
#print(firstName + lastName)

result= firstName * lastName
print("The result is: ", result)
